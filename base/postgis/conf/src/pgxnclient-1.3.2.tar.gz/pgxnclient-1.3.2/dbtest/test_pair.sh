#!/bin/bash
source env.sh
export EXTENSION=pair
source _test_template.sh
