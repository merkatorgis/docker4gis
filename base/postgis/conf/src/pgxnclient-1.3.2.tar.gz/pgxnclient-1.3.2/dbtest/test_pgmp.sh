#!/bin/bash
source env.sh
export EXTENSION=pgmp
source _test_template.sh
