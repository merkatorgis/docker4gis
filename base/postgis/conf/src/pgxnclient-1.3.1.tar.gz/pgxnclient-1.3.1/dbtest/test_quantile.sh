#!/bin/bash
source env.sh
export EXTENSION=quantile
export LEVEL=--testing
source _test_template.sh
