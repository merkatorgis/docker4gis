#!/bin/bash
source env.sh
export EXTENSION=pyrseas
export TEST_DB=pyrseas_testdb
source _test_template.sh
