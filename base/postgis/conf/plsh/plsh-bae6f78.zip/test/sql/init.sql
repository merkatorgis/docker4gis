\i plsh.sql
