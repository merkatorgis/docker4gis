### Context
*Please explain here below what you were doing when the issue happened*



### Steps to Reproduce
*Please break down here below all the needed steps to reproduce the issue*

1.
2.
3.

### Current Result
*Please describe here below the current result you got*



### Expected result
*Please describe here below what should be the expected behaviour*


### System trying to connect to and version
*What system were you trying to connect (PostgreSQL, MySQL, etc) and what version*


### Additional info
*Please add any information of interest here below*
